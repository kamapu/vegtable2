#' @importFrom methods new
#' @importFrom DBI dbGetQuery dbSendQuery
#' @importFrom biblioDB read_pg
#' @importFrom taxlist clean_strings
#' @importClassesFrom RPostgreSQL PostgreSQLConnection
#' @importClassesFrom taxlist taxlist
#' @importClassesFrom vegtable vegtable
#' 
NULL
# TODO: replace read_pg for a general function working with any DB
